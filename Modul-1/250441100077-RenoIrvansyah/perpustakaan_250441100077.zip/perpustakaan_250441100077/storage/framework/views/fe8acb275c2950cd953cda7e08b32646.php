

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>

    <section class="position-relative">
        <img src="<?php echo e(asset('images/perpus.jpeg')); ?>" class="w-100" style="height: 600px; object-fit: cover;">

        <div class="position-absolute top-50 start-50 translate-middle text-center">
            <h1 class="display-3 fw-bold">SELAMAT DATANG</h1>
            <p class="fs-4 fw-bold">DI PERPUSTAKAAN - RIBUAN KATA</p>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100077\resources\views/home.blade.php ENDPATH**/ ?>