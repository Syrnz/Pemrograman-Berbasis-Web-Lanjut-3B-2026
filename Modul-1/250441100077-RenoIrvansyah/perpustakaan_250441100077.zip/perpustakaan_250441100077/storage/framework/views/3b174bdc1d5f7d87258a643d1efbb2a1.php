

<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('content'); ?>

    <section id="daftar-buku" class="mt-3">
        <div class="container mb-3">
            <div class="row mb-3 text-center">
                <div class="col">
                    <h2> Daftar Buku </h2>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3 mb-3" style="width: 380px;">
                        <?php if (isset($component)) { $__componentOriginal4043f1b18f0274362ee9613e82bd7ae0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0 = $attributes; } ?>
<?php $component = App\View\Components\BookCard::resolve(['id' => $item['id'],'judul' => $item['judul'],'penulis' => $item['penulis'],'tahun' => $item['tahun'],'kategori' => $item['kategori'],'poster' => $item['poster']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('book-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BookCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0)): ?>
<?php $attributes = $__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0; ?>
<?php unset($__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4043f1b18f0274362ee9613e82bd7ae0)): ?>
<?php $component = $__componentOriginal4043f1b18f0274362ee9613e82bd7ae0; ?>
<?php unset($__componentOriginal4043f1b18f0274362ee9613e82bd7ae0); ?>
<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_250441100077\resources\views/buku/index.blade.php ENDPATH**/ ?>