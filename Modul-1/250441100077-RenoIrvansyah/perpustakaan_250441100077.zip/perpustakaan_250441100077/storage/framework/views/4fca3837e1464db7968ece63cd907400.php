<div>
    <div class="card">
        <img src="<?php echo e(asset('images/buku/' . $poster)); ?>" class="card-img-top img-fluid object-fit-contain mt-3"
            style="height: 200px;" alt="">
        <div class="card-body">
            <h3 class="text-center"><?php echo e($judul); ?></h3>
            <hr class="border border-dark border-3 opacity-75">
            <p class="card-text">
                <strong>Penulis:</strong> <?php echo e($penulis); ?>

            </p>
            <hr class="border border-dark opacity-75">
            <p class="card-text">
                <strong>Tahun Terbit:</strong> <?php echo e($tahun); ?>

            </p>
            <p class="card-text">
                <strong>Kategori:</strong> <?php echo e($kategori); ?>

            </p>
            <a href="<?php echo e(route('buku.detail', $id)); ?>" class="btn btn-secondary">Lihat Detail</a>

            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\perpustakaan_250441100077\resources\views/components/book-card.blade.php ENDPATH**/ ?>